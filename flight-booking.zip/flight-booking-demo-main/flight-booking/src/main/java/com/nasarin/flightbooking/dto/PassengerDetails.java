package com.nasarin.flightbooking.dto;

import lombok.Data;

@Data
public class PassengerDetails {
    private String name ;
    private String gender ;
    private String age ;
}
