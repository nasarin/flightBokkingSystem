package com.nasarin.flightbooking.controller;

import com.nasarin.flightbooking.dto.TicketBookingDto;
import com.nasarin.flightbooking.service.FlightBookingService;
import com.nasarin.flightbooking.service.RegisterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("/api/v1.0/flight/booking")
@RestController
public class FlightBookingController {
    @Autowired
    private FlightBookingService flightBookingService;

    @PostMapping
    public ResponseEntity<String> ticketBooking(@RequestBody TicketBookingDto ticketBookingDto){
        return ResponseEntity.ok( flightBookingService.ticketBooking(ticketBookingDto));
    }
}
