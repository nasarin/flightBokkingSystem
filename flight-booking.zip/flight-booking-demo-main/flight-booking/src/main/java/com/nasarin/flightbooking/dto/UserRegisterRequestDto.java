package com.nasarin.flightbooking.dto;

import lombok.Data;

@Data
public class UserRegisterRequestDto {
    private String userName;
    private String password;

}
