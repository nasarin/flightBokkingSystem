package com.nasarin.flightbooking.service;

import com.nasarin.flightbooking.dto.TicketBookingDto;
import com.nasarin.flightbooking.dto.UserRegisterRequestDto;
import com.nasarin.flightbooking.model.FlightDetails;
import com.nasarin.flightbooking.model.User;
import com.nasarin.flightbooking.repository.FlightBookingRepository;
import com.nasarin.flightbooking.repository.UserRegisterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Service
public class FlightBookingService {
    @Autowired
    private FlightBookingRepository flightBookingRepository;

    public  String ticketBooking(TicketBookingDto ticketBookingDto) {

        String resultMsg = "";
        FlightDetails flightDetails = toRegisterEntity(ticketBookingDto);

        FlightDetails savedUser  =  flightBookingRepository.save(flightDetails);

        if(Objects.nonNull(savedUser)){
            resultMsg = "Success";
        }else{
            resultMsg = "Failure";
        }

        return resultMsg;
    }

    private FlightDetails toRegisterEntity(TicketBookingDto ticketBookingDto) {
        FlightDetails flightDetails = new FlightDetails();
        flightDetails.setName(ticketBookingDto.getName());
        flightDetails.setEmailId(ticketBookingDto.getEmailId());
        flightDetails.setNoOfSeats(ticketBookingDto.getNoOfSeats());
        flightDetails.setMeal(ticketBookingDto.getMeal());
        flightDetails.setFlightId(ticketBookingDto.getFlightId());
        //flightDetails.setPassengerDetails(ticketBookingDto.getPassengerDetails());
        flightDetails.setSeatNo(ticketBookingDto.getSeatNo());

        return  flightDetails;
    }

}
