package com.nasarin.flightbooking.repository;

import com.nasarin.flightbooking.model.FlightDetails;
import com.nasarin.flightbooking.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FlightBookingRepository extends JpaRepository<FlightDetails, Integer> {
}
